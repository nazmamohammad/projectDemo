package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.client.SchedulePlan;
@Repository("dao")
@Transactional
public class PlanDaoImpl implements IPlanDao{
	@PersistenceContext
	private EntityManager entityManager;
	public PlanDaoImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public SchedulePlan addDetails(SchedulePlan plan) {
		// TODO Auto-generated method stub
		entityManager.persist(plan);
		entityManager.flush();
		return plan;
	}
	

	@Override
	public ArrayList<SchedulePlan> displayAll(SchedulePlan plan) {
		// TODO Auto-generated method stub
		TypedQuery<SchedulePlan> query=entityManager.createQuery("select s from SchedulePlan s",SchedulePlan.class);
		ArrayList< SchedulePlan> arrayList = (ArrayList<SchedulePlan>) query.getResultList();
		return arrayList;
	}

	@Override
	public List<SchedulePlan> getResult(Integer id) {
		// TODO Auto-generated method stub
		TypedQuery<SchedulePlan> query = entityManager.createQuery("select s from SchedulePlan s where fid = :fid",SchedulePlan.class);
		query.setParameter("fid", id);
		List<SchedulePlan> list = query.getResultList();
		return list;
		
	}

	@Override
	public boolean deletePlan(int fId) {
		// TODO Auto-generated method stub
		boolean flag=false;
		SchedulePlan sp = entityManager.find(SchedulePlan.class, fId);
		if(sp!=null){
			entityManager.remove(sp);	
			flag = true;
		}
		return flag;
	}

	@Override
	public ArrayList<SchedulePlan> displayAllDelete(SchedulePlan plan) {
		// TODO Auto-generated method stub
		TypedQuery<SchedulePlan> query=entityManager.createQuery("select s from SchedulePlan s",SchedulePlan.class);
		ArrayList< SchedulePlan> arrayList = (ArrayList<SchedulePlan>) query.getResultList();
		return arrayList;
	}

	

}
