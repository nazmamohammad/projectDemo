package com.cg.controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.client.SchedulePlan;
import com.cg.service.IPlanService;

@Controller
public class PlanController {
	@Autowired
	IPlanService service;

	@RequestMapping("index")
	public String homepage() {
		String view = null;
		view = "HomePage";
		return view;
	}

	@RequestMapping("plan")
	public String addDetails(Model m) {
		SchedulePlan plan = new SchedulePlan();
		LocalDate date = LocalDate.now();
		m.addAttribute("date", date);
		m.addAttribute("plan", plan);
		m.addAttribute("period", new String[] { "ENGLISH", "MATHS", "PHYSICS",
				"CHEMISTRY" });
		return "EnterPlan";
	}

	@RequestMapping(value = "insert", method = RequestMethod.POST)
	public String insertQues(@ModelAttribute("plan") @Valid SchedulePlan plan,
			BindingResult result, Model model) {
		String view = null;
		if (result.hasErrors()) {
			view = "EnterPlan";
		} else {
			SchedulePlan obj = service.addDetails(plan);
			model.addAttribute("plan", obj);
			model.addAttribute("id", plan.getfId());
			view = "Success";

		}
		System.out.println(view);
		return view;
	}

	@RequestMapping("viewall")
	public String displayAll(Model m) {
		SchedulePlan plan = new SchedulePlan();
		ArrayList<SchedulePlan> list = service.displayAll(plan);
		m.addAttribute("list", list);
		System.out.println(list);
		return "ViewAll";
	}

	@RequestMapping("viewid")
	public String viewById(Model m) {
		SchedulePlan plan = new SchedulePlan();
		m.addAttribute("plan", plan);
		return "ViewBy";
	}

	@RequestMapping(value = "viewby", method = RequestMethod.POST)
	public String viewBy(@ModelAttribute("plan") @RequestParam String fId,
			Model model) {
		String target = null;
		Integer id = Integer.parseInt(fId);
		List<SchedulePlan> list = service.getResult(id);
		if (!list.isEmpty()) {
			model.addAttribute("list", list);
			System.out.println(list);
			target = "Result";
		} else {
			String msg = "Not Found";
			model.addAttribute("msg", msg);
			target = "Result";
		}
		return target;
	}
	@RequestMapping("deleteall")
	public String displayAllDelete(Model m) {
		SchedulePlan plan = new SchedulePlan();
		ArrayList<SchedulePlan> list = service.displayAll(plan);
		m.addAttribute("list", list);
		System.out.println(list);
		return "deleteAll";
	}

	@RequestMapping("delete.obj")
	public ModelAndView deletePlan(@RequestParam int fId) {

		ModelAndView mv = new ModelAndView();
		boolean flag = service.deletePlan(fId);
		if (flag) {

			mv.addObject("fId", fId);
			mv.setViewName("delete");
		} else {
			mv.setViewName("error");
		}
		return mv;
	}

	public PlanController() {
		// TODO Auto-generated constructor stub
	}

}
