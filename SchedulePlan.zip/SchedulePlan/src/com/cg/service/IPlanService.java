package com.cg.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.client.SchedulePlan;

public interface IPlanService {
	public SchedulePlan addDetails(SchedulePlan plan);

	public ArrayList<SchedulePlan> displayAll(SchedulePlan plan);

	public List<SchedulePlan> getResult(Integer id);

	public boolean deletePlan(int fId);
	
	public ArrayList<SchedulePlan> displayAllDelete(SchedulePlan plan);
	
	}
