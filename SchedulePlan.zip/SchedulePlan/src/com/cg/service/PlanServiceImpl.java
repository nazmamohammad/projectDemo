package com.cg.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.client.SchedulePlan;
import com.cg.dao.IPlanDao;

@Service("service")
public class PlanServiceImpl implements IPlanService{
	@Autowired
	IPlanDao dao;
	public PlanServiceImpl() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public SchedulePlan addDetails(SchedulePlan plan) {
		// TODO Auto-generated method stub
		return dao.addDetails(plan);
	}
	@Override
	public ArrayList<SchedulePlan> displayAll(SchedulePlan plan) {
		// TODO Auto-generated method stub
		return dao.displayAll(plan);
	}
	@Override
	public List<SchedulePlan> getResult(Integer id) {
		// TODO Auto-generated method stub
		return dao.getResult(id);
	}
	@Override
	public boolean deletePlan(int fId) {
		// TODO Auto-generated method stub
		return dao.deletePlan(fId);
	}
	@Override
	public ArrayList<SchedulePlan> displayAllDelete(SchedulePlan plan) {
		// TODO Auto-generated method stub
		return dao.displayAllDelete(plan);
	}
	
	

}
