package com.cg.timesheet.dao;

import java.util.List;

import com.cg.timesheet.client.TimeSheet;

public interface ITimeSheetDAO {

	public TimeSheet addDetails(TimeSheet plan);

	public List<TimeSheet> getResult(String empId);

}
