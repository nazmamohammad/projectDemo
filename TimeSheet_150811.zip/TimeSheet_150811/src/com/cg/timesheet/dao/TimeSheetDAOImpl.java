package com.cg.timesheet.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import com.cg.timesheet.client.TimeSheet;

@Repository("dao")
@Transactional
public class TimeSheetDAOImpl implements ITimeSheetDAO {
	@PersistenceContext
	private EntityManager entityManager;
	public TimeSheetDAOImpl() {
		// TODO Auto-generated constructor stub
	}
	
	
	@Override
	public TimeSheet addDetails(TimeSheet plan) {
		// TODO Auto-generated method stub
		entityManager.persist(plan);
		entityManager.flush();
		return plan;
	}


	@Override
	public List<TimeSheet> getResult(String empId) {
		// TODO Auto-generated method stub
		TypedQuery<TimeSheet> query = entityManager.createQuery("select s from TimeSheet s where emp_id= :emp_id",TimeSheet.class);
		query.setParameter("emp_id", empId);
		List<TimeSheet> list = query.getResultList();
		return list;
	}

}
