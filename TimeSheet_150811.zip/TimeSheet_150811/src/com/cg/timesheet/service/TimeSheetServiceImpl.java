package com.cg.timesheet.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.timesheet.client.TimeSheet;
import com.cg.timesheet.dao.ITimeSheetDAO;

@Service("service")
public class TimeSheetServiceImpl implements ITimeSheetService{
	@Autowired
	ITimeSheetDAO dao;
	@Override
	public TimeSheet addDetails(TimeSheet plan) {
		// TODO Auto-generated method stub
		return dao.addDetails(plan);
	}
	@Override
	public List<TimeSheet> getResult(String empId) {
		// TODO Auto-generated method stub
		return dao.getResult(empId);
	}

}
