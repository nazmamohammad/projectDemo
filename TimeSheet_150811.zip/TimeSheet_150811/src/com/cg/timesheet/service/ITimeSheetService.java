package com.cg.timesheet.service;

import java.util.List;

import com.cg.timesheet.client.TimeSheet;

public interface ITimeSheetService {

	public TimeSheet addDetails(TimeSheet plan);

	public List<TimeSheet> getResult(String empId);

}
