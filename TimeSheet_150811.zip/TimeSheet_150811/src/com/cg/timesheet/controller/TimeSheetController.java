package com.cg.timesheet.controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.cg.timesheet.client.TimeSheet;
import com.cg.timesheet.service.ITimeSheetService;

@Controller
public class TimeSheetController {
	@Autowired
	ITimeSheetService service;
	
	//Below code snipet for redirecting to homepage 
	@RequestMapping("index")
	public String homepage() {
		String view = null;
		view = "AuditorTimeSheet";
		return view;
	}
	//Below code snipet for display of data entry page
	@RequestMapping("enterTimeSheet")
	public String addDetails(Model m) {
		TimeSheet plan = new TimeSheet();
		LocalDate date = LocalDate.now();
		m.addAttribute("date", date);
		m.addAttribute("plan", plan);
		m.addAttribute("hour", new String[] { "DATA_ENTRY", "ACCOUNTS_TALLY",
				"LEDGER_POSTINGS", "BALANCE_SHEETS", "RETURNS_FILLING" });
		return "enterTimeSheet";
	}
	
	//Below code snipet for inserting the data and displaying success page
	@RequestMapping(value = "insert", method = RequestMethod.POST)
	public String insertQues(@ModelAttribute("plan") @Valid TimeSheet plan,
			BindingResult result, Model model) {
		String view = null;
		if (result.hasErrors()) {
			view = "enterTimeSheet";
		} else {
			TimeSheet obj = service.addDetails(plan);
			model.addAttribute("plan", obj);
			model.addAttribute("id", plan.getTimeId());
			view = "addTimeSheet";

		}
		System.out.println(view);
		return view;
	}
	
	/* The below code id for displaying the entered time sheet*/
	
	@RequestMapping("viewid")
	public String viewById(Model m) {
		TimeSheet plan = new TimeSheet();
		m.addAttribute("plan", plan);
		return "listTimeSheet";
	}

	@RequestMapping(value = "viewby", method = RequestMethod.POST)
	public String viewBy(@ModelAttribute("plan") @RequestParam String empId,
			Model model) {
		
		
		String target = null;
		
		
		List<TimeSheet> list = service.getResult(empId);
		if (!list.isEmpty()) {
			model.addAttribute("list", list);
			System.out.println(list);
			target = "Result";
		} else {
			String msg = "No time sheet recorded!!";
			model.addAttribute("msg", msg);
			target = "Result";
		}
		return target;
	}
	
	

}
